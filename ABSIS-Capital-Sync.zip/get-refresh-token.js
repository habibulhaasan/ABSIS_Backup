// get-refresh-token.js
// Run ONCE locally: node get-refresh-token.js
// Uses built-in https — no npm install needed.

const http     = require('http');
const https    = require('https');
const url      = require('url');
const { exec } = require('child_process');

// ─── FILL THESE IN ────────────────────────────────────────────────────────
const CLIENT_ID     = process.env.GOOGLE_CLIENT_ID     || '938799579766-55mheguj6eagojrcgbehnvrjm9mevk42.apps.googleusercontent.com';
const CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || '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';
const REDIRECT_URI  = 'http://localhost:3000/oauth/callback';
// ──────────────────────────────────────────────────────────────────────────

const SCOPE = 'https://www.googleapis.com/auth/drive.file';

const authUrl =
  `https://accounts.google.com/o/oauth2/v2/auth` +
  `?client_id=${CLIENT_ID}` +
  `&redirect_uri=${encodeURIComponent(REDIRECT_URI)}` +
  `&response_type=code` +
  `&scope=${encodeURIComponent(SCOPE)}` +
  `&access_type=offline` +
  `&prompt=consent`;

function httpsPost(hostname, path, body) {
  return new Promise((resolve, reject) => {
    const data = body.toString();
    const req  = https.request({
      hostname,
      path,
      method: 'POST',
      headers: {
        'Content-Type':   'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(data),
      },
    }, (res) => {
      let raw = '';
      res.on('data', chunk => raw += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(raw)); }
        catch (e) { reject(new Error('Bad JSON: ' + raw)); }
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  if (!parsed.pathname.startsWith('/oauth/callback')) return;

  const code = parsed.query.code;
  if (!code) { res.end('No code received. Try again.'); return; }

  try {
    const body = new URLSearchParams({
      code,
      client_id:     CLIENT_ID,
      client_secret: CLIENT_SECRET,
      redirect_uri:  REDIRECT_URI,
      grant_type:    'authorization_code',
    });

    const data = await httpsPost(
      'oauth2.googleapis.com',
      '/token',
      body
    );

    if (data.refresh_token) {
      console.log('\n✅ SUCCESS! Add these to your .env.local:\n');
      console.log(`GOOGLE_CLIENT_ID=${CLIENT_ID}`);
      console.log(`GOOGLE_CLIENT_SECRET=${CLIENT_SECRET}`);
      console.log(`GOOGLE_REFRESH_TOKEN=${data.refresh_token}`);
      console.log('\n');
      res.end('<h2>✅ Done! Check your terminal for the refresh token. You can close this tab.</h2>');
    } else {
      console.error('Unexpected response:', data);
      res.end(`<pre>Error: ${JSON.stringify(data, null, 2)}</pre>`);
    }
  } catch (err) {
    console.error(err);
    res.end('Error: ' + err.message);
  }

  server.close();
});

server.listen(3000, () => {
  console.log('\n🔑 Opening Google OAuth in your browser...');
  console.log('If browser does not open, visit this URL manually:\n');
  console.log(authUrl + '\n');

  const cmd = process.platform === 'win32' ? `start "" "${authUrl}"`
            : process.platform === 'darwin' ? `open "${authUrl}"`
            : `xdg-open "${authUrl}"`;
  exec(cmd);
});